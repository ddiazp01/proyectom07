package model

import "time"

//Peticion struct
type Peticion struct {
	Palabra string
}

//Idioma struct
type Idioma struct {
	Nombre string
}

//Traductor struct
type Traductor struct {
	PalabraTraduccion string
}

//Filtro struct
type Filtro struct {
	Fecha time.Time
}
