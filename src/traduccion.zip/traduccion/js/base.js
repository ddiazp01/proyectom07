$(document).ready (function () {
  
    $("#btnEnviar").click(function(){
        var texto =  $("#txtTexto").val();
        
        var peticion= {
            
            Palabra: texto,
      
        }
   
        $.ajax({
            type: "POST",
            url: "http://localhost:8080/envio",
            data: JSON.stringify(peticion),
            dataType: "JSON",
            contentType:"application/json",
        })
        .done(function(data) {
            $("#respuesta p").html(data.Palabra);
        })
        .fail(function(data) {
            console.log( "La solicitud no se ha completado correctamente." );
        })
        .always(function(data){
            console.log("complete")
        })
    });
    function Historial_UI(array) {
        var tbody = $("#historial tbody");
        tbody.children().remove();
        if(array != null && array.length > 0) {
    
            for(var x = 0; x < array.length; x++) {
                tbody.append(
                    "<tr><td>" + array[x].ID + 
                    "</td><td>" + array[x].Palabra + 

                    "</td></tr>");
            }
        } else {
            tbody.append('<tr><td colspan="3">No hay registros de hoy</td></tr>');
            
        }
    }
});